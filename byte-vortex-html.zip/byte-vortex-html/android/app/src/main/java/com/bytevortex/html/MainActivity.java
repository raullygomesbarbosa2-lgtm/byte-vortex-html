package com.bytevortex.html;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebResourceResponse;
import android.widget.Toast;
import android.webkit.ValueCallback;
import androidx.webkit.WebViewAssetLoader;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> uploadCallback;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(9,7,20));
    getWindow().setNavigationBarColor(Color.rgb(9,7,20));
    web = new WebView(this);
    web.setBackgroundColor(Color.rgb(9,7,20));
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(true);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    s.setSupportMultipleWindows(true);
    CookieManager.getInstance().setAcceptCookie(true);
    CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
    final WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
    web.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req){return loader.shouldInterceptRequest(req.getUrl());}
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){return route(req.getUrl());}
      @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return route(Uri.parse(url));}
      private boolean route(Uri u){
        String scheme=u.getScheme()==null?"":u.getScheme().toLowerCase();
        if(scheme.equals("file")||scheme.equals("data")||scheme.equals("about")||scheme.equals("javascript"))return false;
        if(scheme.equals("https")||scheme.equals("http")){
          if(u.getHost()!=null && (u.getHost().equals("localhost")||u.getHost().equals("appassets.androidplatform.net")))return false;
          try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível abrir o link",Toast.LENGTH_SHORT).show();}
          return true;
        }
        try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
        return true;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
        if(uploadCallback!=null)uploadCallback.onReceiveValue(null); uploadCallback=callback;
        try{startActivityForResult(params.createIntent(),101);return true;}catch(Exception e){uploadCallback=null;callback.onReceiveValue(null);return false;}
      }
      @Override public boolean onCreateWindow(WebView view,boolean dialog,boolean gesture,android.os.Message resultMsg){
        WebView popup=new WebView(MainActivity.this);
        popup.setWebViewClient(new WebViewClient(){
          @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
            Uri u=r.getUrl();try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){} v.destroy();return true;
          }
          @Override public boolean shouldOverrideUrlLoading(WebView v,String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception ignored){}v.destroy();return true;}
        });
        ((WebView.WebViewTransport)resultMsg.obj).setWebView(popup);resultMsg.sendToTarget();return true;
      }
    });
    setContentView(web);
    web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==101&&uploadCallback!=null){uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));uploadCallback=null;}
  }
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
