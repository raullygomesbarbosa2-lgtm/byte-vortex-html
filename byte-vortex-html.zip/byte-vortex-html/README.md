# Byte Vortex — APK gerado a partir do HTML enviado

O APK empacota o arquivo HTML original enviado pelo usuário como interface local em WebView. CSS/JS Tailwind, Google Fonts, Font Awesome e módulos Firebase usam serviços online, portanto exigem conexão. O HTML contém modo local com localStorage; sincronização de banco precisa de configuração Firebase compatível.

## Compilar
Abra `android/` no Android Studio, sincronize Gradle e use Build > Build APK(s). APK de CI é debug/teste; gere e proteja uma chave de assinatura própria antes de distribuir oficialmente.

O HTML anuncia funcionalidades (login, pagamentos, downloads) que dependem da implementação/configuração externa. Não foram testadas em dispositivo; PIX mostrado como texto não deve ser tratado como confirmação de pagamento.
