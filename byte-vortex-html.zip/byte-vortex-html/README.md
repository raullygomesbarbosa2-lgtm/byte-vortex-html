# Byte Vortex — APK gerado do HTML mais recente

Este build incorpora exatamente o HTML enviado em 14/11/2026 e a arte `122273.png` fornecida anteriormente. A interface roda localmente em WebView. Tailwind, Google Fonts, Font Awesome e Firebase usam rede.

A sincronização Firestore depende de `__firebase_config`, `__app_id` e regras/configuração do Firebase de origem; sem elas o app usa armazenamento local do navegador e os dados não sincronizam entre dispositivos. O painel de dono no HTML é apenas uma barreira de interface (senha local fraca), não autenticação segura. O formulário PIX produz texto/QR informativo e não confirma pagamento; não use para pagamentos reais.

APK de CI assinado com chave debug, só para teste. Para distribuição, assine com keystore de produção privado e proteja-o.
