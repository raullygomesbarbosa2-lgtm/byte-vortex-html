# Byte Vortex — Android 4.4 KitKat

Versão 1.2.0 com `minSdk 19` (Android 4.4), o HTML mais recente enviado e a arte `122273.png`. O build de lançamento instala em outros celulares Android compatíveis.

A CI gera uma chave de assinatura temporária por build; o usuário não precisa fornecer chave para instalar. **Ela não é preservada**: próximas versões não poderão atualizar esta instalação no lugar; será preciso desinstalar e instalar novamente (os dados locais podem ser apagados). Para atualizações sem reinstalar, configure uma chave privada duradoura e mantenha cópias de segurança.

HTML transpila o JavaScript principal para o WebView antigo do KitKat; Firebase modular continua indisponível no KitKat, então catálogo local e sem sincronização entre aparelhos. Tailwind/fontes/ícones usam CDN e exigem internet. Não testado fisicamente em KitKat.

Login admin local é inseguro e não deve ser usado como proteção. PIX exibido é somente um texto, não confirma cobrança. Não processar pagamentos reais.
