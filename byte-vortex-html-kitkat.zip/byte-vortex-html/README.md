# Byte Vortex — Android 4.4 KitKat

Build do HTML mais recente enviado, com a arte `122273.png`. APK configurado com `minSdk 19` e target API 28. A compilação prepara a aplicação JavaScript para o WebView antigo do KitKat usando Babel (Chrome 30) e inclui polyfills. A parte Firebase modular é mantida no HTML mas não executa no KitKat; não há Firebase credentials incluídas. Portanto, usa catálogo local e não sincroniza entre dispositivos.

Tailwind, Google Fonts e Font Awesome ainda usam CDN e precisam de internet. API de arquivo / galeria em Android 4.4 pode variar conforme o aparelho. Não foi testado fisicamente em um celular KitKat.

O painel de dono no HTML é uma barreira local fraca, não autenticação segura. O texto PIX não confirma pagamento; não use painel/pagamentos em produção. APK de CI assinado com debug key, apenas teste.
