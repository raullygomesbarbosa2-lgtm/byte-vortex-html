package com.bytevortex.html;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.content.Intent;
import android.net.Uri;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    if (android.os.Build.VERSION.SDK_INT >= 21) {
      getWindow().setStatusBarColor(Color.rgb(9,7,20));
      getWindow().setNavigationBarColor(Color.rgb(9,7,20));
    }
    web = new WebView(this);
    web.setBackgroundColor(Color.rgb(9,7,20));
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    if (android.os.Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    s.setSupportMultipleWindows(true);
    CookieManager.getInstance().setAcceptCookie(true);
    if (android.os.Build.VERSION.SDK_INT >= 21) CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return route(Uri.parse(url));}
      private boolean route(Uri u){
        String scheme=u.getScheme()==null?"":u.getScheme().toLowerCase();
        if(scheme.equals("file")||scheme.equals("data")||scheme.equals("about")||scheme.equals("javascript"))return false;
        if(scheme.equals("https")||scheme.equals("http")){
          if(u.getHost()!=null && (u.getHost().equals("localhost")||u.getHost().equals("appassets.androidplatform.net")))return false;
          try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível abrir o link",Toast.LENGTH_SHORT).show();}
          return true;
        }
        try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
        return true;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onCreateWindow(WebView view,boolean dialog,boolean gesture,android.os.Message resultMsg){
        WebView popup=new WebView(MainActivity.this);
        popup.setWebViewClient(new WebViewClient(){
          @Override public boolean shouldOverrideUrlLoading(WebView v,String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception ignored){}v.destroy();return true;}
        });
        ((WebView.WebViewTransport)resultMsg.obj).setWebView(popup);resultMsg.sendToTarget();return true;
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
