const fs=require('fs'); const path=require('path'); const babel=require('@babel/core');
const htmlPath=path.resolve(__dirname,'../android/app/src/main/assets/index.html');
let html=fs.readFileSync(htmlPath,'utf8');
// The main app is the final ordinary inline script. Firebase's separate module script is intentionally left untouched; KitKat does not support ES modules and no Firebase config is embedded in this APK.
const marker='  <script>\n'; const pos=html.lastIndexOf(marker);
if(pos<0) throw new Error('Main classic script not found');
const start=pos+marker.length; const end=html.indexOf('  </script>',start);
if(end<0) throw new Error('Closing script not found');
const source=html.slice(start,end);
const result=babel.transformSync(source,{presets:[[require.resolve('@babel/preset-env'),{targets:{chrome:'30'},modules:false,bugfixes:false}]],comments:true,compact:false,sourceType:'script'}).code;
const polyfills=`<script src="core-js.min.js"></script><script>(function(){if(!Element.prototype.matches)Element.prototype.matches=Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector;if(!Element.prototype.closest)Element.prototype.closest=function(s){var e=this;while(e&&e.nodeType===1){if(e.matches(s))return e;e=e.parentElement||e.parentNode}return null};if(!Element.prototype.remove)Element.prototype.remove=function(){if(this.parentNode)this.parentNode.removeChild(this)};if(!Array.prototype.find)Array.prototype.find=function(f,t){for(var i=0;i<this.length;i++)if(f.call(t,this[i],i,this))return this[i]};if(!Array.prototype.findIndex)Array.prototype.findIndex=function(f,t){for(var i=0;i<this.length;i++)if(f.call(t,this[i],i,this))return i;return -1};if(!String.prototype.includes)String.prototype.includes=function(s,p){return this.indexOf(s,p||0)!==-1};if(!String.prototype.startsWith)String.prototype.startsWith=function(s,p){p=p||0;return this.substr(p,s.length)===s};if(window.NodeList&&!NodeList.prototype.forEach)NodeList.prototype.forEach=Array.prototype.forEach;if(window.HTMLCollection&&!HTMLCollection.prototype.forEach)HTMLCollection.prototype.forEach=Array.prototype.forEach})()</script>\n`;
html=html.slice(0,pos)+polyfills+'  <script>\n'+result+'\n'+html.slice(end);
fs.writeFileSync(htmlPath,html);
fs.copyFileSync(require.resolve('core-js-bundle/minified.js'),path.resolve(__dirname,'../android/app/src/main/assets/core-js.min.js'));
console.log('Transpiled main HTML script for Android 4.4 WebView and bundled ES polyfills.');
